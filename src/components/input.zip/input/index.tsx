import Input from "./text";
import Textarea from "./textarea";

export { Input, Textarea };
